from odoo import models, fields, api

class Operation(models.Model):
    _name = 'gestion.operation'
    _description = 'Opération'

    name = fields.Char('Nom', required=True)
    date_operation = fields.Date('Date', required=True)
    montant = fields.Float('Montant', required=True)
    type_operation = fields.Selection([
        ('entree', 'Entrée'),
        ('sortie', 'Sortie')
    ], string='Type', required=True)
    caisse_id = fields.Many2one('gestion.caisse', string='Caisse', ondelete='cascade')
    status = fields.Selection([
        ('draft', 'Brouillon'),
        ('confirmed', 'Confirmé'),
        ('cancelled', 'Annulé')
    ], string='Statut', default='draft')  

    @api.model
    def create(self, vals):
        operation = super(Operation, self).create(vals)
        if operation.caisse_id:
            operation.caisse_id._compute_solde()
        return operation

    def write(self, vals):
        res = super(Operation, self).write(vals)
        for operation in self:
            if operation.caisse_id:
                operation.caisse_id._compute_solde()
        return res

    def unlink(self):
        for operation in self:
            caisse = operation.caisse_id
            super(Operation, self).unlink()
            if caisse:
                caisse._compute_solde()
        return True

from odoo import models, fields, api

class Caisse(models.Model):
    _name = 'gestion.caisse'
    _description = 'Caisse'

    name = fields.Char('Nom', required=True)
    journal_id = fields.Many2one('account.journal', 'Journal', required=True)
    code = fields.Char('Code de la caisse', required=True)
    montant_max = fields.Float('Montant Max', required=True)
    operation_ids = fields.One2many('gestion.operation', 'caisse_id', 'Opérations')
    solde = fields.Float(string='Solde', compute='_compute_solde', store=True)

    @api.depends('operation_ids.montant', 'operation_ids.type_operation')
    def _compute_solde(self):
        for caisse in self:
            solde = 0.0
            for operation in caisse.operation_ids:
                if operation.type_operation == 'entree':
                    solde += operation.montant
                elif operation.type_operation == 'sortie':
                    solde -= operation.montant
            caisse.solde = solde

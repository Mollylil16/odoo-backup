{
    'name': 'Gestion de Caisse',
    'version': '1.0',
    'summary': 'Module de gestion des caisses',
    'author': 'Votre Nom',
    'category': 'Accounting',
    'depends': ['base', 'account'],
    'data': [
        'security/ir.model.access.csv',
        'views/gestion_caisse_views.xml',
        'views/gestion_operation_views.xml',
    ],
    'installable': True,
    'application': True,
    'auto_install': False,
    'icon':'/gestion_caisse/static/description/caisse.png'
    

    
}
